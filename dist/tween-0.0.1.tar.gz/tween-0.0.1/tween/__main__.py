from tween import print_ease_types
print_ease_types()
